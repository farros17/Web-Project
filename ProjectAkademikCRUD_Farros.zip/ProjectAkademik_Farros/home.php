<?php
session_start();

if (isset($_SESSION['id_pengguna']) && isset($_SESSION['username'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HOME</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEJ10K4sTtwhzVZoob2tEJLqjV1zSyF8t1HVyDWcnJ1m2lTA7a9Y4x5JqYc4A" crossorigin="anonymous">
        <style>
            body {
                background-color: #f7f7f7;
                font-family: Arial, sans-serif;
            }
            .container {
                margin-top: 80px;
                text-align: center;
                background-color: #fff;
                padding: 40px;
                border-radius: 8px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            }
            h1 {
                color: #007bff;
                font-size: 2.5rem;
            }
            .btn-logout {
                background-color: #dc3545;
                color: white;
                font-size: 1.2rem;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
            }
            .btn-logout:hover {
                background-color: #c82333;
                transition: background-color 0.3s ease;
            }
            .welcome-img {
                max-width: 100%;
                height: auto;
                margin-top: 30px;
                border-radius: 8px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Hello, <?php echo $_SESSION['username']; ?>!</h1>
            <p class="lead">Welcome to your homepage. You are logged in now.</p>

            <img src="https://media.istockphoto.com/id/1127929107/vector/welcome-lettering-sign-isolated-vector.jpg?s=612x612&w=0&k=20&c=kH2mqRoV8-1vutUYwGhdpzx-Wt24Gbq7Oz0sKxZcBWU=" alt="Welcome Image" class="welcome-img">

            <br>
            <a href="logout.php" class="btn-logout mt-4">Logout</a>
            <a href="data_pengguna.php" class="btn-logout mt-4">Data pengguna</a>
            <a href="tambah_pengguna.php" class="btn-logout mt-4">Tambah pengguna</a>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0WzHjDXFuRVDJ8uISrfsc6gH9vcXGT7J6RzzA9xjeUoTCaAK" crossorigin="anonymous"></script>
    </body>
    </html>
<?php
} else {
    header("Location: index.php");
    exit();
}
?>