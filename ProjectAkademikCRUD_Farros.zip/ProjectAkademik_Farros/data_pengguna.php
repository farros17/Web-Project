<?php
session_start();
include "koneksi.php";
$sql = "SELECT * FROM pengguna";
$result2 = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Daftar Pengguna</h2>
        <table class="table table-bordered table-striped text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID Pengguna</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_row($result2)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row[0]); ?></td>
                        <td><?php echo htmlspecialchars($row[1]); ?></td>
                        <td><?php echo htmlspecialchars($row[2]); ?></td>
                        <td>
                            <a href='editdata.php?id=<?php echo $row[0]; ?>' class='btn btn-warning btn-sm'>EDIT</a>
                            <a href='hapusdata.php?id=<?php echo $row[0]; ?>' class='btn btn-danger btn-sm' onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">HAPUS</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="text-center">
            <a href='home.php' class='btn btn-primary'>Kembali ke Home</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
