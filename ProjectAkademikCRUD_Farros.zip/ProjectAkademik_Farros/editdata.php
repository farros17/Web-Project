<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Pengguna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <a href="data_pengguna.php" class="btn btn-primary mb-3">Lihat Semua Data</a>
        <div class="card shadow-lg p-4">
            <h3 class="text-center mb-4">Edit Data Pengguna</h3>
            <?php 
            session_start(); 
            include "koneksi.php"; 
            $id = $_GET['id']; 
            $sql = "SELECT * FROM pengguna WHERE id_pengguna='$id'"; 
            $result2 = mysqli_query($conn, $sql); 
            while ($row = mysqli_fetch_array($result2)) { ?> 
                <form action="update.php" method="post"> 
                    <input type="hidden" name="id_pengguna" value="<?php echo htmlspecialchars($row[0]); ?>">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($row[1]); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" value="<?php echo htmlspecialchars($row[2]); ?>">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form> 
            <?php } ?> 
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
