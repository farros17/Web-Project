<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
        }

        .left-side {
            flex: 1;
            background-image: url('https://portalberita.stekom.ac.id/assets/images/berita/kenapa-sekarang-cari-kerja-susah.jpg?t=');
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
        }

        .right-side {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgb(255, 255, 255);
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background-color:rgb(152, 168, 180);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(126, 37, 37, 0.1);
        }

        .login-card h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .login-card .form-control {
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 12px;
            font-size: 16px;
        }

        .login-card .btn {
            padding: 12px;
            font-size: 16px;
            border-radius: 8px;
            background-color: #269a33;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }

        .login-card .btn:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>

<body>

    <div class="left-side"></div>

    <div class="right-side">
        <div class="login-card">
            <h2>LOGIN</h2>
            <form action="login.php" method="post">
                <?php if (isset($_GET['error'])) { ?>
                    <div class="error"><?php echo $_GET['error']; ?></div>
                <?php } ?>

                <div class="mb-3">
                    <label for="uname" class="form-label">Username</label>
                    <input type="text" id="uname" name="uname" class="form-control" placeholder="Enter your username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn w-100">Login</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>

</html>