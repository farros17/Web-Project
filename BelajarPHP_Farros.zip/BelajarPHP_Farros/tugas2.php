<!DOCTYPE html>
<html>
<head>
    <title>Tabel Perkalian</title>
    <style>
        table {
            border-collapse: collapse;
            margin: 20px auto;
        }
        table, th, td {
            border: 2px solid red;
            text-align: center;
        }
        th {
            font-size: 20px;
            color: red;
            text-align: center;
            padding: 10px;
        }
        td {
            padding: 8px;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center; color: red;">Tabel Menggunakan Perulangan</h2>
    <table>
        <?php
        // Baris luar (angka pertama)
        for ($i = 1; $i <= 10; $i++) {
            echo "<tr>";
            // Kolom dalam (angka kedua)
            for ($j = 1; $j <= 10; $j++) {
                echo "<td>" . ($i * $j) . "</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>
