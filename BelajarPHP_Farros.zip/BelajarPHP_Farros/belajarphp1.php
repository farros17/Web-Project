<?php
$nama ="Farros Sanni Apriyanto";
$nisn ="23359";
$ttl ="16/04/2007";
$umur = 17 ;
$asal ="SMKN 5 Surakarta";
$hobi ="Main Game";
$skor1 = 90.25 ;
$skor2 = 80.15 ;
$lolos = false ;



print '<h1><span style="color: blue;">Hai</span></h1><br>';
print '<h2><span style="color: green;">Hai</span></h2><br>';
print '<h3><span style="color: red;">Hai</span></h3><br>';
print '<h4><span style="color: purple;">Hai</span></h4><br>';
print '<h5><span style="color: orange;">Hai</span></h5><br>';
print '<h6><span style="color: grey;">Hai</span></h6><br>';

echo "Nama = " .$nama. "<br>";
echo "Nisn = " .$nisn. "<br>";
echo "Tanggal Lahir = " .$ttl. "<br>";
echo "Umur = " .$umur. "<br>";
echo "Asal Sekolah = " .$asal. "<br>";
echo "Hobi = " .$hobi. "<br>";
echo "Total Skor = " .$skor1 + $skor2. "<br>";

if($lolos == true)
echo "<h3> Peserta Lolos ke Babak Selanjutnya</h3>";
else
echo "Peserta Harus Berhenti di sini";

?>