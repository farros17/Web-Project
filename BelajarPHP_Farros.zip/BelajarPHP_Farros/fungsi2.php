<?php
function hitumur($thn_lhr, $thn_now){
    $umur = $thn_now - $thn_lhr;
    return $umur;
}

$umursaya = hitumur(2007, 2025);
echo "umur saya adalah" .$umursaya." tahun" ;
?>