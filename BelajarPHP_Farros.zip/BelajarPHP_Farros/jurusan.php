<?php

$jurusan =$_POST['jurusan'];

if ($jurusan == "TKP") {
    echo "Jurusanmu adalah Teknik Konstruksi dan Propereti";
} elseif ($jurusan == "RPL") {
    echo "Jurusanmu adalah Rekayasa Perangkat Lunak";
} elseif ($jurusan == "TKR") {
    echo "Jurusanmu adalah Teknik Kendaraan Ringan";
} elseif ($jurusan == "TSM") {
    echo "Jurusanmu adalah Teknik Sepeda Motor";
} elseif ($jurusan == "TM") {
    echo "Jurusanmu adalah Teknik Mesin";
} elseif ($jurusan == "TEI") {
    echo "Jurusanmu adalah Teknik Elektronika Industri";
} elseif ($jurusan == "TOI") {
    echo "Jurusanmu adalah Teknik Otomasi Industri";
} elseif ($jurusan == "DPIB") {
    echo "Jurusanmu adalah Desain Pemodelan dan Informasi Bangunan";
} else{
    echo "kamu bukan siswa SMKN 5 Surakarta";
}
?>