<!DOCTYPE html>
<html>
<head>
    <title>Deret Fibonacci</title>
</head>
<body>
    <h2>Deret Fibonacci Hingga 100</h2>
    <?php
    function fibonacci($n) {
        if ($n <= 1) {
            return $n;
        }
        return fibonacci($n - 1) + fibonacci($n - 2);
    }

    $n = 0;
    $result = fibonacci($n);
    echo "<p>Deret Fibonacci antara 1 hingga 100:</p>";
    echo "<p>";

    while ($result <= 100) {
        echo $result . " ";
        $n++;
        $result = fibonacci($n);
    }

    echo "</p>";
    ?>
</body>
</html>
