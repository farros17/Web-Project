<?php
function indonesia(){
    echo "Selamat datang di webku<br>";
}
function inggris(){
    echo "welcome to my web<br>";
}
function jerman(){
    echo "Willkommen auf meiner web<br>";
}
function italia(){
    echo "Benvenuti nel Mio Web<br>";
}
$bahasa="jerman";
$bahasa();
$bahasa="indonesia";
$bahasa();
?>